/*
 * receive.h
 *
 *  Created on: 20-05-2024
 *      Author: Windows
 */

#ifndef SOURCE_MID_RECEIVE_RECEIVE_H_
#define SOURCE_MID_RECEIVE_RECEIVE_H_



#endif /* SOURCE_MID_RECEIVE_RECEIVE_H_ */

#include "app/framework/include/af.h"


void RECEIVE_OnOffCommandHandle(uint8_t clusterSpecific, uint8_t cmd, uint8_t DEP, uint8_t* buffer, uint8_t payloadStartIndex);
void RECEIVE_ColorControlCommandHandle(uint8_t clusterSpecific, uint8_t cmd, uint8_t* buffer, uint8_t payloadStartIndex);
