/*
 * timer.c
 *
 *  Created on: Aug 19, 2024
 *      Author: Admin
 */

#include "timer.h"
#define BUFFER_SIZE 1440
// Duty cycle global variable for IRQ handler use
uint32_t dutyCycle_CC0 = 0, dutyCycle_CC1 = 0, dutyCycle_CC2 = 0;
uint32_t NEWdutyCycle_CC0 = 0, NEWdutyCycle_CC1 = 0, NEWdutyCycle_CC2 = 0;
static PWMInitStruct_t AttributeStruct;
EmberEventControl changePWMEventControl;
uint8_t* baseQueueAddress;
uint16_t baseQueueLen;
uint8_t* currentQueuePtr;
uint16_t remainQueueLen;
uint8_t currentReadBit=0;
timerMode_t TimerMode = Queue;
uint32_t debugCount=0;
uint16_t count= 0;
// Globally declared link descriptor
LDMA_Descriptor_t descLink;

//1.25us = 100 NOP
#define SHORT_DELAY __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
        			__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
        			__NOP(); __NOP(); __NOP(); __NOP(); __NOP();__NOP(); __NOP(); __NOP();; __NOP(); __NOP();  \
        			__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
					__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
					__NOP(); __NOP(); __NOP(); __NOP(); __NOP();__NOP(); __NOP(); __NOP();; __NOP(); __NOP();  \
					__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
					__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
					__NOP(); __NOP(); __NOP(); __NOP(); __NOP();__NOP(); __NOP(); __NOP();; __NOP(); __NOP();  \
					__NOP(); __NOP(); __NOP(); __NOP(); __NOP();__NOP(); __NOP(); __NOP();; __NOP(); __NOP();
void Timer_QueueModeHandle();
void Timer_SingleModeHandle();
void initTIMER_WS2812(GPIO_Port_TypeDef gpioPort, uint8_t gpioPin, uint8_t* buffer, uint16_t bufferlen , GPIO_Mode_TypeDef gpioMode)
{
	baseQueueAddress = buffer;
	baseQueueLen = bufferlen;

	AttributeStruct.channelCount =1;
	AttributeStruct.CC0Port = gpioPort;
	AttributeStruct.CC0Pin = gpioPin;
	GPIO_PinModeSet(gpioPort, gpioPin, gpioMode, 0);

	uint32_t timerFreq, topValue, dutyCount;
	TIMER_Init_TypeDef timerInit = TIMER_INIT_DEFAULT;
	TIMER_InitCC_TypeDef timerCCInit = TIMER_INITCC_DEFAULT;

	// Don't start counter on initialization
	timerInit.enable = false;

	// PWM mode sets/clears the output on compare/overflow events
	timerCCInit.mode = timerCCModePWM;
	timerCCInit.outInvert = false;
	timerCCInit.filter = true;
	timerCCInit.cmoa = timerOutputActionClear;
	TIMER_Init(TIMER1, &timerInit);

	// Enable routes
	GPIO->TIMERROUTE[1].ROUTEEN  |= GPIO_TIMER_ROUTEEN_CC0PEN;
	GPIO->TIMERROUTE[1].CC0ROUTE = (gpioPort << _GPIO_TIMER_CC0ROUTE_PORT_SHIFT) | (gpioPin << _GPIO_TIMER_CC0ROUTE_PIN_SHIFT);

	TIMER_InitCC(TIMER1, 0, &timerCCInit);
	// Set top value to overflow at the desired PWM_FREQ frequency
	timerFreq = CMU_ClockFreqGet(cmuClock_TIMER1) / (timerInit.prescale + 1);
	emberAfCorePrintln("FREQ: %d\n" ,CMU_ClockFreqGet(cmuClock_TIMER1));
	topValue = (timerFreq / PWM_FREQ);
	TIMER_TopSet(TIMER1, topValue);
	TIMER_CompareSet(TIMER1, 0, 32);
	// Now start the TIMER
	//TIMER_Enable(TIMER1, true);

	// Enable TIMER0 compare event interrupts to update the duty cycle
	TIMER_IntEnable(TIMER1, TIMER_IEN_CC0);
	NVIC_EnableIRQ(TIMER1_IRQn);

}

void initLDMA(uint8_t *buffer, uint16_t size)
{
  // Default LDMA initialization
  LDMA_Init_t init = LDMA_INIT_DEFAULT;
  LDMA_Init(&init);

  // Request transfers on CC0 peripheral requests
  // Transfer from the RAM buffer to CC0 output register in a continuous loop
  LDMA_Descriptor_t xfer =
    LDMA_DESCRIPTOR_LINKREL_M2P_BYTE(&buffer,             // Memory source address
                                     &TIMER1->CC[0].OCB,  // Output compare buffer register
									 size,         			// Number of transfers to make
                                     0);                  // Link to same descriptor

  // Store descriptor globally
  descLink = xfer;

  // Transfer one word per request
  descLink.xfer.size = ldmaCtrlSizeWord;

  // Do not ignore single requests.  Transfer data on every request.
  descLink.xfer.ignoreSrec = 0;

  // Do not request an interrupt on completion of all transfers
  descLink.xfer.doneIfs  = 1;

  // Start transfer, LDMA will trigger after first compare event
  LDMA_TransferCfg_t periTransferTx =
  			            LDMA_TRANSFER_CFG_PERIPHERAL(ldmaPeripheralSignal_TIMER0_CC0);
  LDMA_StartTransfer(0, (void*)&periTransferTx, (void*)&descLink);
}

void initTIMER_PWM(PWMInitStruct_t initStruct)
{
	AttributeStruct = initStruct;
	GPIO_PinModeSet(initStruct.CC0Port, initStruct.CC0Pin, gpioModePushPull, 0);
	GPIO_PinModeSet(initStruct.CC1Port, initStruct.CC1Pin, gpioModePushPull, 0);
	GPIO_PinModeSet(initStruct.CC2Port, initStruct.CC2Pin, gpioModePushPull, 0);


	uint32_t timerFreq, topValue, dutyCount;
	TIMER_Init_TypeDef timerInit = TIMER_INIT_DEFAULT;
	TIMER_InitCC_TypeDef timerCCInit = TIMER_INITCC_DEFAULT;

	// Don't start counter on initialization
	timerInit.enable = false;

	// PWM mode sets/clears the output on compare/overflow events
	timerCCInit.mode = timerCCModePWM;
	timerCCInit.outInvert = true;
	TIMER_Init(TIMER1, &timerInit);

	// Enable routes
	if(initStruct.channelCount >= 1){
	  GPIO->TIMERROUTE[1].ROUTEEN  |= GPIO_TIMER_ROUTEEN_CC0PEN;
	  GPIO->TIMERROUTE[1].CC0ROUTE = (initStruct.CC0Port << _GPIO_TIMER_CC0ROUTE_PORT_SHIFT) | (initStruct.CC0Pin << _GPIO_TIMER_CC0ROUTE_PIN_SHIFT);
	}
	if(initStruct.channelCount >= 2){
	  GPIO->TIMERROUTE[1].ROUTEEN  |= GPIO_TIMER_ROUTEEN_CC1PEN;
	  GPIO->TIMERROUTE[1].CC1ROUTE = (initStruct.CC1Port << _GPIO_TIMER_CC1ROUTE_PORT_SHIFT) | (initStruct.CC1Pin << _GPIO_TIMER_CC1ROUTE_PIN_SHIFT);
	}

	if(initStruct.channelCount >= 3){
	  GPIO->TIMERROUTE[1].ROUTEEN  |= GPIO_TIMER_ROUTEEN_CC2PEN;
	  GPIO->TIMERROUTE[1].CC2ROUTE = (initStruct.CC2Port << _GPIO_TIMER_CC2ROUTE_PORT_SHIFT) | (initStruct.CC2Pin << _GPIO_TIMER_CC2ROUTE_PIN_SHIFT);
	}


	TIMER_InitCC(TIMER1, 0, &timerCCInit);
	TIMER_InitCC(TIMER1, 1, &timerCCInit);
	TIMER_InitCC(TIMER1, 2, &timerCCInit);

	// Set top value to overflow at the desired PWM_FREQ frequency
	timerFreq = CMU_ClockFreqGet(cmuClock_TIMER1) / (timerInit.prescale + 1);
	topValue = (timerFreq / PWM_FREQ);
	TIMER_TopSet(TIMER1, topValue);

	// Set dutyCycle global variable and compare value for initial duty cycle
	dutyCycle_CC0 = INITIAL_DUTY_CYCLE;
	dutyCycle_CC1 = INITIAL_DUTY_CYCLE;
	dutyCycle_CC2 = INITIAL_DUTY_CYCLE;

	dutyCount = (topValue * INITIAL_DUTY_CYCLE) / 100;

	TIMER_CompareSet(TIMER1, 0, dutyCount);
	TIMER_CompareSet(TIMER1, 1, dutyCount);
	TIMER_CompareSet(TIMER1, 2, dutyCount);

	// Now start the TIMER
	//TIMER_Enable(TIMER0, true);

	// Enable TIMER0 compare event interrupts to update the duty cycle
	TIMER_IntEnable(TIMER1, TIMER_IEN_CC0);
	TIMER_IntEnable(TIMER1, TIMER_IEN_CC1);
	TIMER_IntEnable(TIMER1, TIMER_IEN_CC2);
	NVIC_EnableIRQ(TIMER1_IRQn);
	NVIC_SetPriority(TIMER1_IRQn, 6);
	TIMER_Enable(TIMER1, false);
}

//void LDMA_IRQHandler(){
//	uint32_t flags = LDMA_IntGet();
//	LDMA_IntClear(flags);
//	stopPWM();
//}
/**************************************************************************//**
 * @brief
 *    Interrupt handler for TIMER0
 *
 * @note
 *    In this example, the duty cycle of the output waveform does not
 *    change unless the value of the dutyCycle global variable is
 *    modified outside the scope of this function.
 *
 *    Alternatively, other code could be inserted here to modify the
 *    duty cycle based on some other input, e.g. the voltage measured
 *    by the IADC on a given input channel.
 *****************************************************************************/
void TIMER1_IRQHandler(void)
{
	//If 0 then 32 if 1 then 54
	//uint32_t newDutyCount;
	// Acknowledge the interrupt
	uint32_t flags = TIMER_IntGet(TIMER1);
	TIMER_IntClear(TIMER1, flags);
	Timer_QueueModeHandle();
	//emberAfCorePrintln("Countdown:%d", remainQueueLen);
}

void timerSetDutyCycle(uint8_t CC0, uint8_t CC1, uint8_t CC2){
	emberEventControlSetInactive(changePWMEventControl);
	NEWdutyCycle_CC0 = CC0;
	NEWdutyCycle_CC1 = CC1;
	NEWdutyCycle_CC2 = CC2;
	TimerMode = Single;
	emberEventControlSetDelayMS(changePWMEventControl, 100);
}
void changePWMEventHandler(){
	emberEventControlSetInactive(changePWMEventControl);
	switch (TimerMode){
	case Single:
		break;
	case Queue:
		TIMER_CompareBufSet(TIMER1, 0, *currentQueuePtr);
		currentQueuePtr++;
		remainQueueLen--;
		startPWM();
		break;
	case Idle:
		break;
	}

}
void Timer_QueueModeHandle(){
	static uint8_t lastCode;
	if(remainQueueLen >0){
		if (*currentQueuePtr != lastCode){
			TIMER_CompareBufSet(TIMER1, 0, *currentQueuePtr);
			lastCode = *currentQueuePtr;
		}
		currentQueuePtr++;
		remainQueueLen--;
		startPWM();
	}else{
		stopPWM();
		//emberAfCorePrintln("Count%d",count);
	}
}
void timerQueueDutyCycle(){
	emberEventControlSetInactive(changePWMEventControl);
	TimerMode = Queue;
	currentQueuePtr = baseQueueAddress;
	remainQueueLen = baseQueueLen;
	emberEventControlSetDelayMS(changePWMEventControl,10);
}

void stopPWM(){
	//LDMA_StopTransfer(0);
	TIMER_Enable(TIMER1, false);
	GPIO_PinOutClear(AttributeStruct.CC0Port, AttributeStruct.CC0Pin);
	GPIO_PinOutClear(AttributeStruct.CC1Port, AttributeStruct.CC1Pin);
	GPIO_PinOutClear(AttributeStruct.CC2Port, AttributeStruct.CC2Pin);
}

void startPWM(){
	TIMER_Enable(TIMER1, true );
	//LDMA_TransferCfg_t periTransferTx =
			            //LDMA_TRANSFER_CFG_PERIPHERAL(ldmaPeripheralSignal_TIMER0_CC0);
	//LDMA_StartTransfer(0, (void*)&periTransferTx, (void*)&descLink);
}



