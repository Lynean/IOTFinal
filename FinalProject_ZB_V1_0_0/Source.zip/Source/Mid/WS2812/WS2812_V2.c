/*
 * ws2812.c
 *
 *  Created on: Jul 26, 2024
 *      Author: DungTranBK
 */

/******************************************************************************/
/*                              INCLUDE FILES                                 */
/******************************************************************************/

#include "Source/Driver/driver.h"
#include "WS2812_V2.h"

#ifdef  DEBUG_WS2812
#define DBG_WS2812_SEND_STR(x)              Dbg_sendString((uint8_t*)x)
#define DBG_WS2812_SEND_BYTE_HEX(x)         Dbg_sendOneByteHex(x)
#define DBG_WS2812_SEND_INT(x)              Dbg_sendInt(x)
#define DBG_WS2812_SEN_HEX(x)               Dbg_sendHex32(x)
#else
#define DBG_WS2812_SEND_STR(x)
#define DBG_WS2812_SEND_BYTE_HEX(x)
#define DBG_WS2812_SEND_INT(x)
#define DBG_WS2812_SEN_HEX(x)
#endif

/******************************************************************************/
/*                            PRIVATE FUNCTION                                */
/******************************************************************************/


/******************************************************************************/
/*                              PRIVATE DATA                                  */
/******************************************************************************/
#define WS2812_NUM_LEDS        12
//#define WS2812_DATA_PIN        BSP_IO_PORT_03_PIN_01
#define WS2812_PORT				gpioPortC
#define WS2812_PIN				1
#define WS2812_RST_TIME_US     500

#define LVL_LOW                0x04
#define LVL_HIGH               0x05

#define MACRO_WS2812_BUS_LOW    GPIO_PinOutClear(WS2812_PORT, WS2812_PIN);
#define MACRO_WS2812_BUS_HIGH   GPIO_PinOutSet(WS2812_PORT, WS2812_PIN);
//~0.6uS
#define T1L_TIME	__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP();
//~0.7uS
#define T1H_TIME	__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP();__NOP(); __NOP(); __NOP();

//~0.35uS
#define T0H_TIME	__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP();
//~0.8uS
#define T0L_TIME	__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
					__NOP(); __NOP();

#define LONG_TIME	__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP();

#define SHORT_TIME	__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
                    __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();  \
					__NOP(); __NOP();

static void WS2812_reset(void);

/******************************************************************************/
/*                            EXPORTED FUNCTIONS                              */
/******************************************************************************/
static void __delay_us(uint32_t us){
	for(uint32_t i = 0; i < us; i++){
		T0L_TIME;
		T0L_TIME;
		T0L_TIME;
		T0L_TIME;
		T0L_TIME;
		T0L_TIME;
		T0L_TIME;
		T0L_TIME;
	}
}
/**
 * @func    WS2812_reset
 * @brief
 * @param   None
 * @retval  None
 */
static void WS2812_reset(void)
{
    MACRO_WS2812_BUS_LOW;
    __delay_us(WS2812_RST_TIME_US);
}

/**
 * @func    WS2812_send_test
 * @brief
 * @param   None
 * @retval  None
 */
void WS2812_set(uint8_t* par_led, uint8_t len)
{
    WS2812_reset();
    __disable_irq();
//    R_BSP_PinAccessEnable();
    for(uint8_t i = 0; i < len; i++)
    {
        uint8_t temp = par_led[i];

        for(uint8_t j = 0; j < 8; j++)
        {
            if(((temp >> j)&0x01) == 0x1)
            {
                // SET
                MACRO_WS2812_BUS_HIGH;   // 0.7 us
                T1H_TIME;
                // CLEAR
                MACRO_WS2812_BUS_LOW;	//0.6 us
                T1L_TIME;
            }
            else
            {
                // SET
                MACRO_WS2812_BUS_HIGH;
                T0H_TIME;
                // CLEAR
                MACRO_WS2812_BUS_LOW;
                T0L_TIME;
            }
        }
    }
//    R_BSP_PinAccessDisable();
    __enable_irq();
}

/**
 * @func    WS2812_init
 * @brief
 * @param   None
 * @retval  None
 */
void WS2812_init(void)
{
	CMU_ClockEnable(cmuClock_GPIO, true);
	emberAfCorePrintln("GPIOFREQ: %d\n" ,CMU_ClockFreqGet(cmuClock_GPIO));
	GPIO_PinModeSet(WS2812_PORT, WS2812_PIN, gpioModeDisabled, 0);
    WS2812_reset();
}

// End file
