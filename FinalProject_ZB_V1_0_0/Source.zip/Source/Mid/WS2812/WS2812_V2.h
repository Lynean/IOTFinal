/*
 * WS2812_V2.h
 *
 *  Created on: Sep 23, 2024
 *      Author: Admin
 */

#ifndef SOURCE_MID_WS2812_WS2812_V2_H_
#define SOURCE_MID_WS2812_WS2812_V2_H_

void WS2812_init(void);
void WS2812_set(uint8_t* par_led, uint8_t len);

#endif /* SOURCE_MID_WS2812_WS2812_V2_H_ */
