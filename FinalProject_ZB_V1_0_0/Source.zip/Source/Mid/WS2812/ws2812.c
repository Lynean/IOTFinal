/*
 * ws2812.c
 *
 *  Created on: Sep 14, 2024
 *      Author: Admin
 */
#include "ws2812.h"
#include "Source/Driver/driver.h"



#define LED_NUM		60
#define COLOR_NUM 	3
//180*8
#define QUEUE_LEN	1440
//G-R-B

#define CODE_0_DUTYCYCLE 	(32)
#define CODE_1_DUTYCYCLE	(54)

uint8_t outputBuffer[QUEUE_LEN];
GPIO_Port_TypeDef ws2812_Port;
uint8_t ws2812_Pin;
EmberEventControl WS2812SubmitEventControl;
uint8_t testNum;
WSColor_t currentStruct;
static void splitByteBit(uint8_t* buffer,BITstruct_t byte);
void WS2812Display_Struct();

void WS2812_Init(GPIO_Port_TypeDef gpioPort, uint8_t gpioPin){
	ws2812_Port = gpioPort;
	ws2812_Pin = gpioPin;
	initTIMER_WS2812(ws2812_Port, ws2812_Pin,(uint8_t*)outputBuffer, QUEUE_LEN, gpioModeWiredAndAlternateFilter);
	WSColor_t initColorStruct;
	initColorStruct.green.byte= 0;
	initColorStruct.red.byte= 0;
	initColorStruct.blue.byte= 0;
	WS2812SetColor_All(initColorStruct);
	initColorStruct.green.byte= 255;
	for(int i=0; i< 60; i++){
			WS2812SetColor_Index(i, initColorStruct);
	}
	WS2812Display_Struct();
	//initLDMA();
}

static void splitByteBit(uint8_t* buffer,BITstruct_t byte){
	*(buffer+0) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT7;
	*(buffer+1) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT6;
	*(buffer+2) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT5;
	*(buffer+3) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT4;
	*(buffer+4) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT3;
	*(buffer+5) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT2;
	*(buffer+6) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT1;
	*(buffer+7) = CODE_0_DUTYCYCLE + (CODE_1_DUTYCYCLE - CODE_0_DUTYCYCLE)*byte.BIT0;
}

void WS2812SetColor_Index(uint8_t Num, WSColor_t colorStruct){
	emberEventControlSetInactive(WS2812SubmitEventControl);
	uint16_t base = ((uint16_t)Num)*3*8;
	splitByteBit((outputBuffer+base), (BITstruct_t)(colorStruct.green.byteAdvance));
	splitByteBit((outputBuffer+base+8), (BITstruct_t)(colorStruct.red.byteAdvance));
	splitByteBit((outputBuffer+base+16), (BITstruct_t)(colorStruct.blue.byteAdvance));
	emberEventControlSetDelayMS(WS2812SubmitEventControl, 100);
}

void WS2812SubmitEventHandler(){
	emberEventControlSetInactive(WS2812SubmitEventControl);
	//emberAfCorePrintln("SETTING ALL UP");
	timerQueueDutyCycle();
	emberEventControlSetDelayMS(WS2812SubmitEventControl, 100);
}

void WS2812SetColor_All(WSColor_t colorStruct){
	emberEventControlSetInactive(WS2812SubmitEventControl);
	for(int i=0; i< 60; i++){
		WS2812SetColor_Index(i, colorStruct);
	}
	emberEventControlSetDelayMS(WS2812SubmitEventControl, 100);
}

void WS2812Display_Struct(){
	emberEventControlSetInactive(WS2812SubmitEventControl);
	for(int i=0; i< QUEUE_LEN; i++){
		emberAfCorePrintln("Data:%d", outputBuffer[i]);
	}
	emberEventControlSetDelayMS(WS2812SubmitEventControl, 100);
}





