/*
 * ws2812.h
 *
 *  Created on: Sep 14, 2024
 *      Author: Admin
 */


/*
 * ledPWM.h
 *
 *  Created on: Aug 19, 2024
 *      Author: Admin
 */

#include "app/framework/include/af.h"

typedef struct{
	uint8_t BIT0 :1;
	uint8_t BIT1 :1;
	uint8_t BIT2 :1;
	uint8_t BIT3 :1;
	uint8_t BIT4 :1;
	uint8_t BIT5 :1;
	uint8_t BIT6 :1;
	uint8_t BIT7 :1;
}BITstruct_t;

typedef union {
	uint8_t byte;
	BITstruct_t byteAdvance;
}AdvanceByte_t;
typedef struct{
	AdvanceByte_t red;
	AdvanceByte_t green;
	AdvanceByte_t blue;
}WSColor_t;

void WS2812SetColor_Index(uint8_t Num, WSColor_t colorStruct);
void WS2812_Init(GPIO_Port_TypeDef gpioPort, uint8_t gpioPortPin);
void WS2812SetColor_All(WSColor_t colorStruct);
