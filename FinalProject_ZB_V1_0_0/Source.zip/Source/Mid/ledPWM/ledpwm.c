/*
 * ledPWM.c
 *
 *  Created on: Aug 19, 2024
 *      Author: Admin
 */

#include <Source/Mid/ledPWM/ledpwm.h>
#include "Source/Driver/driver.h"
#include <math.h>

void ledPWM_Init(ledNum_t led){
	PWMInitStruct_t ledPWMInitStruct;
	if(led == BOARD0){
		ledPWMInitStruct.channelCount = 3;
		ledPWMInitStruct.CC0Port = gpioPortA;
		ledPWMInitStruct.CC0Pin = 4;
		ledPWMInitStruct.CC1Port = gpioPortA;
		ledPWMInitStruct.CC1Pin = 3;
		ledPWMInitStruct.CC2Port = gpioPortA;
		ledPWMInitStruct.CC2Pin = 0;
		initTIMER_PWM(ledPWMInitStruct);
	}
	else if(led == BOARD1){
		ledPWMInitStruct.channelCount = 3;
		ledPWMInitStruct.CC0Port = gpioPortD;
		ledPWMInitStruct.CC0Pin = 0;
		ledPWMInitStruct.CC1Port = gpioPortD;
		ledPWMInitStruct.CC1Pin = 1;
		ledPWMInitStruct.CC2Port = gpioPortD;
		ledPWMInitStruct.CC2Pin = 2;
		initTIMER_PWM(ledPWMInitStruct);
	}
}

void ledPWMControl(uint8_t r, uint8_t g, uint8_t b, uint8_t on){
	if (on){
		emberAfCorePrintln("Changing Color to (%d %d %d)", r,g,b);
		startPWM();
		timerSetDutyCycle(r, g, b);
	}
	else{
		stopPWM();
	}
}


